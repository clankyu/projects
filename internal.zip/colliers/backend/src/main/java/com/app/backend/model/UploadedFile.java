package com.app.backend.model;

import jakarta.persistence.*;

@Entity
public class UploadedFile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String originalFileName;
    private String storedFilePath;

    @ManyToOne
    @JoinColumn(name = "project_item_id")
    private ProjectItem projectItem;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getOriginalFileName() { return originalFileName; }
    public void setOriginalFileName(String originalFileName) { this.originalFileName = originalFileName; }
    public String getStoredFilePath() { return storedFilePath; }
    public void setStoredFilePath(String storedFilePath) { this.storedFilePath = storedFilePath; }
    public ProjectItem getProjectItem() { return projectItem; }
    public void setProjectItem(ProjectItem projectItem) { this.projectItem = projectItem; }
}
