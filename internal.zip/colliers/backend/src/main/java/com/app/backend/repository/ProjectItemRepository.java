package com.app.backend.repository;

import com.app.backend.model.ProjectItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectItemRepository extends JpaRepository<ProjectItem, Long> {
}
