package com.app.backend.model;

import jakarta.persistence.*;
import java.util.List;
import java.util.ArrayList;

@Entity
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String clientEmail;
    private String uniqueLinkUuid;

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private List<ProjectItem> items = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getClientEmail() { return clientEmail; }
    public void setClientEmail(String clientEmail) { this.clientEmail = clientEmail; }
    public String getUniqueLinkUuid() { return uniqueLinkUuid; }
    public void setUniqueLinkUuid(String uniqueLinkUuid) { this.uniqueLinkUuid = uniqueLinkUuid; }
    public List<ProjectItem> getItems() { return items; }
    public void setItems(List<ProjectItem> items) { this.items = items; }
}
