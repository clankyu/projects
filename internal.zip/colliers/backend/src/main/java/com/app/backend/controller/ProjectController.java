package com.app.backend.controller;

import com.app.backend.model.Project;
import com.app.backend.model.ProjectItem;
import com.app.backend.model.UploadedFile;
import com.app.backend.service.ProjectService;
import com.app.backend.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import java.net.MalformedURLException;
import java.nio.file.Path;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @Autowired
    private FileService fileService;

    @GetMapping("/")
    public String landingPage() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/signup")
    public String signup() {
        return "redirect:/login";
    }

    @GetMapping("/menu")
    public String hostMenu(Model model) {
        model.addAttribute("projects", projectService.findAllProjects());
        return "menu";
    }

    @PostMapping("/project/create")
    public String createProject(@RequestParam String name, @RequestParam String clientEmail) {
        Project project = projectService.createNewProject(name, clientEmail);
        return "redirect:/project/" + project.getUniqueLinkUuid();
    }

    @GetMapping("/project/{uuid}")
    public String viewProject(@PathVariable String uuid, Model model) {
        Project project = projectService.getProjectByUuid(uuid);
        if (project == null) {
            return "error/404";
        }

        Map<String, List<ProjectItem>> itemsByStage = project.getItems().stream()
        .collect(Collectors.groupingBy(item -> item.getStageName().trim()));

        model.addAttribute("project", project);
        model.addAttribute("itemsByStage", itemsByStage);
        return "dashboard";
    }

    @PostMapping("/item/{itemId}/text")
    public String updateText(@PathVariable Long itemId, @RequestParam String textContent) {
        projectService.updateItemText(itemId, textContent);
        ProjectItem item = projectService.getItemById(itemId);
        return "redirect:/project/" + item.getProject().getUniqueLinkUuid();
    }

    @PostMapping("/item/{itemId}/upload")
    public String uploadFile(@PathVariable Long itemId, @RequestParam("file") MultipartFile file) {
        ProjectItem item = projectService.getItemById(itemId);
        if (!file.isEmpty()) {
            try {
                fileService.storeFile(item, file);
            } catch (Exception e) {
                return "redirect:/project/" + item.getProject().getUniqueLinkUuid() + "?error=uploadfail";
            }
        }
        return "redirect:/project/" + item.getProject().getUniqueLinkUuid();
    }

    @GetMapping("/file/{fileId}/download")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId) {
        UploadedFile uploadedFile = fileService.getFileById(fileId);
        if (uploadedFile == null) {
            return ResponseEntity.notFound().build();
        }

        Path filePath = fileService.getFilePath(uploadedFile.getStoredFilePath());
        Resource resource;
        try {
            resource = new UrlResource(filePath.toUri());
            if (resource.exists() || resource.isReadable()) {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + uploadedFile.getOriginalFileName() + "\"")
                        .body(resource);
            } else {
                throw new RuntimeException("Could not read the file!");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error reading file path", e);
        }
    }

    @PostMapping("/file/{fileId}/delete")
    public String deleteFile(@PathVariable Long fileId) {
        ProjectItem item = fileService.getFileById(fileId).getProjectItem();
        String uuid = item.getProject().getUniqueLinkUuid();
        try {
            fileService.deleteFile(fileId);
        } catch (Exception e) {
        }
        return "redirect:/project/" + uuid;
    }
}
