package com.app.backend.repository;

import com.app.backend.model.UploadedFile;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UploadedFileRepository extends JpaRepository<UploadedFile, Long> {
    List<UploadedFile> findByProjectItem_Id(Long projectItemId);
}
