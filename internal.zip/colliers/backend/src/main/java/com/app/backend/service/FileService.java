package com.app.backend.service;

import com.app.backend.model.ProjectItem;
import com.app.backend.model.UploadedFile;
import com.app.backend.repository.UploadedFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import jakarta.transaction.Transactional;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.UUID;

@Service
public class FileService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    @Autowired
    private UploadedFileRepository fileRepository;

    @Transactional
    public UploadedFile storeFile(ProjectItem item, MultipartFile file) throws IOException {

        String originalFilename = file.getOriginalFilename();
        String storedFilename = UUID.randomUUID().toString() + "_" + originalFilename;

        Path targetLocation = Paths.get(uploadDir).toAbsolutePath().normalize().resolve(storedFilename);

        Files.createDirectories(targetLocation.getParent());

        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

        UploadedFile uploadedFile = new UploadedFile();
        uploadedFile.setProjectItem(item);
        uploadedFile.setOriginalFileName(originalFilename);
        uploadedFile.setStoredFilePath(targetLocation.toString());

        return fileRepository.save(uploadedFile);
    }

    @Transactional
    public void deleteFile(Long fileId) throws IOException {
        UploadedFile file = fileRepository.findById(fileId).orElse(null);
        if (file != null) {

            Path filePath = Paths.get(file.getStoredFilePath());
            Files.deleteIfExists(filePath);

            fileRepository.delete(file);
        }
    }

    public Path getFilePath(String storedFilePath) {
        return Paths.get(storedFilePath);
    }

    public List<UploadedFile> getFilesByItem(Long itemId) {
        return fileRepository.findByProjectItem_Id(itemId);
    }

    public UploadedFile getFileById(Long fileId) {
        return fileRepository.findById(fileId).orElse(null);
    }
}
