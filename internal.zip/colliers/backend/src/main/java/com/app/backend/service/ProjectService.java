package com.app.backend.service;

import com.app.backend.model.Project;
import com.app.backend.model.ProjectItem;
import com.app.backend.repository.ProjectRepository;
import com.app.backend.repository.ProjectItemRepository;
import com.app.backend.util.ProjectTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import java.util.UUID;
import java.util.List;

@Service
public class ProjectService {
    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectItemRepository itemRepository;

    @Transactional
    public Project createNewProject(String name, String clientEmail) {

        Project project = new Project();
        project.setName(name);
        project.setClientEmail(clientEmail);
        project.setUniqueLinkUuid(UUID.randomUUID().toString());

        Project savedProject = projectRepository.save(project);

        ProjectTemplate.STRUCTURE.forEach((stageName, templateItems) -> {
            templateItems.forEach(templateItem -> {
                ProjectItem item = new ProjectItem();
                item.setProject(savedProject);
                item.setStageName(stageName.trim());
                item.setItemName(templateItem.name);
                item.setItemType(templateItem.type);

                savedProject.getItems().add(item);
            });
        });

        itemRepository.saveAll(savedProject.getItems());

        return savedProject;
    }

    @Transactional
    public Project getProjectByUuid(String uuid) {
        Project project = projectRepository.findByUniqueLinkUuid(uuid);
        if (project != null) {
            project.getItems().size();
        }

        return project;
    }

    public List<Project> findAllProjects() {
        return projectRepository.findAll();
    }

    public ProjectItem getItemById(Long itemId) {
        return itemRepository.findById(itemId).orElse(null);
    }

    @Transactional
    public void updateItemText(Long itemId, String textContent) {
        ProjectItem item = itemRepository.findById(itemId).orElse(null);
        if (item != null && item.getItemType().name().equals("TEXT")) {
            item.setTextContent(textContent);
            itemRepository.save(item);
        }
    }
}
