package com.app.backend.model;

import jakarta.persistence.*;
import java.util.List;
import java.util.ArrayList;

@Entity
public class ProjectItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String stageName;
    private String itemName;

    @Enumerated(EnumType.STRING)
    private ItemType itemType;

    @Column(columnDefinition = "TEXT")
    private String textContent;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Project project;

    @OneToMany(mappedBy = "projectItem", cascade = CascadeType.ALL)
    private List<UploadedFile> files = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getStageName() { return stageName; }
    public void setStageName(String stageName) { this.stageName = stageName; }
    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }
    public ItemType getItemType() { return itemType; }
    public void setItemType(ItemType itemType) { this.itemType = itemType; }
    public String getTextContent() { return textContent; }
    public void setTextContent(String textContent) { this.textContent = textContent; }
    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }
    public List<UploadedFile> getFiles() { return files; }
    public void setFiles(List<UploadedFile> files) { this.files = files; }
}
