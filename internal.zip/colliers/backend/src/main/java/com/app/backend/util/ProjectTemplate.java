package com.app.backend.util;

import com.app.backend.model.ItemType;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ProjectTemplate {

    public static final Map<String, List<TemplateItem>> STRUCTURE = new LinkedHashMap<>();

    static {
        STRUCTURE.put("Planning/Requisites", List.of(
            new TemplateItem("Objective", ItemType.TEXT),
            new TemplateItem("RequisitesSpecs", ItemType.FILE)
        ));

        STRUCTURE.put("Alternatives", List.of(
            new TemplateItem("MarketInfo", ItemType.FILE),
            new TemplateItem("LaborInfo", ItemType.FILE),
            new TemplateItem("InfrastructureInfo", ItemType.FILE),
            new TemplateItem("GovernmentIncentiveInfo", ItemType.FILE),
            new TemplateItem("PermissionTramitsInfo", ItemType.FILE),
            new TemplateItem("Surveys", ItemType.FILE),
            new TemplateItem("VisitToSites", ItemType.TEXT),
            new TemplateItem("ShortList", ItemType.FILE)
        ));

        STRUCTURE.put("Proposal/Analysis", List.of(
            new TemplateItem("RFP", ItemType.FILE),
            new TemplateItem("ProposalReception", ItemType.FILE),
            new TemplateItem("ProposalAnalysis", ItemType.FILE),
            new TemplateItem("RFI's", ItemType.FILE),
            new TemplateItem("ITAnalysis", ItemType.FILE),
            new TemplateItem("AlternativeITProposals", ItemType.FILE),
            new TemplateItem("Counterproposals", ItemType.FILE)
        ));

        STRUCTURE.put("Closing", List.of(
            new TemplateItem("ComercialNegotation", ItemType.TEXT),
            new TemplateItem("Follow-upCommunication", ItemType.EMAIL),
            new TemplateItem("LOI", ItemType.FILE),
            new TemplateItem("ContractRevision", ItemType.FILE),
            new TemplateItem("Follow-upCommunicationContract", ItemType.EMAIL),
            new TemplateItem("ClosingOfContract", ItemType.FILE),
            new TemplateItem("AnnexComplement", ItemType.FILE)
        ));

        STRUCTURE.put("Legal", List.of(
            new TemplateItem("NDA's", ItemType.FILE),
            new TemplateItem("LessorInfo", ItemType.FILE),
            new TemplateItem("TentantInfo", ItemType.FILE),
            new TemplateItem("PropertyInfo", ItemType.FILE),
            new TemplateItem("ThirdPartyContracts", ItemType.FILE),
            new TemplateItem("CommissionContract", ItemType.FILE),
            new TemplateItem("FeeShareAgreement", ItemType.FILE),
            new TemplateItem("Co-BrokerContracts", ItemType.FILE),
            new TemplateItem("Anti-moneyLaunderingLawNotice", ItemType.FILE),
            new TemplateItem("ExpedientIntegrationShareEmails", ItemType.EMAIL)
        ));

        STRUCTURE.put("Administration", List.of(
            new TemplateItem("AdministrativeDocumentation", ItemType.FILE),
            new TemplateItem("FillingOfNexus", ItemType.TEXT),
            new TemplateItem("ThirdPartyOrders", ItemType.FILE),
            new TemplateItem("RefundableCostsAndTravelExpenses", ItemType.FILE),
            new TemplateItem("CommissionInvoicesFollowUp", ItemType.EMAIL),
            new TemplateItem("CommissionPaymentsFollowUp", ItemType.EMAIL),
            new TemplateItem("ReferalPaymentDocumentationFollowUp", ItemType.EMAIL),
            new TemplateItem("Co-BrokersPaymentDocumentationFollowUp", ItemType.EMAIL),
            new TemplateItem("CharitableDeliveryRecords", ItemType.FILE),
            new TemplateItem("SubstantialDeliveryRecords", ItemType.FILE),
            new TemplateItem("StartOfRentCommissionPayments", ItemType.FILE),
            new TemplateItem("CaseStudy", ItemType.FILE)
        ));
    }

    public static class TemplateItem {
        public String name;
        public ItemType type;

        public TemplateItem(String name, ItemType type) {
            this.name = name;
            this.type = type;
        }
    }
}
