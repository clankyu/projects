package com.app.backend.model;

public enum ItemType {
    TEXT,
    EMAIL,
    FILE,
}
